typedef void (*t_event)()  ;


typedef struct teventnode {
   t_event  eve ;

   unsigned long firetime;
 
  teventnode  *  link ; } teventnode;

#define pevnode teventnode *
